﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using massimo.macaru._5i.FORMDotNetMVC.Models;

namespace massimo.macaru._5i.FORMDotNetMVC.Controllers;


public class HomeController : Controller
{
    private readonly dbContext _context;
    private static List<Prodotto>Prodotti = new List<Prodotto>();

    public HomeController(dbContext context)
    {
        _context = context;
    }
    


    public IActionResult Index()
    {
        //HttpContext.Session.SetString("NomeUtente", "u.name");
        return View();
    }  

    public IActionResult Negozio(){
        
        return View();
    }
    public IActionResult Jordan()
    {
        return View();
    }
    public IActionResult Jordan1()
    {
        return View();
    }
    public IActionResult Jordan3()
    {
        return View();
    }
    public IActionResult Jordan4()
    {
        return View();
    }
    
    public IActionResult NewBalance()
    {
        return View();
    }
    public IActionResult Nike()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        string? nomeUtente = HttpContext.Session.GetString("NomeUtente");
        if (string.IsNullOrEmpty(nomeUtente))
        return Redirect("\\home\\SignUp");
        return View();
    }

    
    [HttpGet]
    public IActionResult SignIn()
    {
       
        return View();
    }

    [HttpPost]
    public IActionResult SignIn(Utente model)
    {
        HttpContext.Session.SetString("NomeUtente",model.NickName);
        return View(model);
    }

    [HttpPost]
public IActionResult SignUp(DatiForm model)
{
    
        HttpContext.Session.SetString("NomeUtente",model.Nome);
        if (ModelState.IsValid)
        {
            
            // Aggiungi il nuovo utente al database utilizzando il contesto
            _context.Utenti.Add(model);
            _context.SaveChanges();

            // Reindirizza l'utente alla pagina di login o ad un'altra pagina di destinazione
            return RedirectToAction("Index", "Home");
        }
        

        // Se il modello non è valido, torna alla pagina di registrazione con gli errori di validazione
        return View(model);
}

    [HttpGet]
    public IActionResult SignUp()
    {      
        return View();
    }
    
      
    [HttpGet]
     public IActionResult Cart(Prodotto p, DatiForm d)
    {
        string? nomeUtente = HttpContext.Session.GetString("NomeUtente");
    if (string.IsNullOrEmpty(nomeUtente))
        return RedirectToAction("SignIn");
    return View(Prodotti);
    }
    [HttpGet]
    public IActionResult Purchase()
    {
        
        
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
