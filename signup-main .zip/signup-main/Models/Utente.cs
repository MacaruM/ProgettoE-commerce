

using System.ComponentModel.DataAnnotations;

public class Utente
{
    [Key]
    public string IdUtente { get; set; }
    public string NickName{ get; set; }
    public string? Password { get; set; }
}
  