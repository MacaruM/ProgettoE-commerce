using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

public class DatiForm
{
    [Key, ValidateNever]
    public int IdRegistrazione { get; set; }

    public string? Nome { get; set; }

    public string? Cognome { get; set; }

    public string? Email { get; set; }

    public DateOnly? DataDiNascita { get; set; }

    public string? Sesso{ get; set; }

   
    public string? Password { get; set; }
    public string? NickName { get; set; }
}
  