
using massimo.macaru._5i.FORMDotNetMVC.Models;
using Microsoft.EntityFrameworkCore;


public class dbContext : DbContext
{
    

    public dbContext(DbContextOptions<dbContext> options)
       : base(options)
	 {
	 }
     
   
    protected override void OnConfiguring(DbContextOptionsBuilder options)
            => options.UseSqlite("Data Source=database.db");

    public DbSet<DatiForm> Utenti { get ; set; }
    public DbSet<Prodotto> Prodotti { get ; set; }
    public DbSet<Utente> Utente { get; set; } = default!;
    
}
