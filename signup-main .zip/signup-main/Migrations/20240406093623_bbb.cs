﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace massimo.macaru._5i.FORMDotNetMVC.Migrations
{
    /// <inheritdoc />
    public partial class bbb : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
